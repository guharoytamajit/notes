echo pods======;kubectl get pods --show-labels;echo rs===========;kubectl get rs --show-labels;echo services=========;kubectl get svc --show-labels
