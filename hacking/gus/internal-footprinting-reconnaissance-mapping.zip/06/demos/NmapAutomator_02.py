# Imports Section
import os


def execute_cmd(tool_name, cmd):
    print "[+] Starting %s ..." % tool_name

    try:
        # Cleanup the command string
        cmd = cmd.rstrip()
        # Execute the command
        os.system(cmd)
    except Exception, e:
        exception_message = str(e)
        print ("[!] Error executing the command: " + cmd + " Reason:\r\n" + exception_message)

    print "[-] Finished %s ..." % tool_name


def convert_xml_to_html(ip_address):
    print "HTML generator"


def live_host_scan(ip_address):
    cmd = "nmap -sn %s" % ip_address
    execute_cmd("Nmap Live Host Scan", cmd)


def simple_tcp_scan(ip_address):
    print "Simple TCP scan"


def full_tcp_scan(ip_address):
    print "Full TCP scan"


def ultimate_tcp_scan(ip_address):
    print "Ultimate TCP Scan"


def regular_udp_scan(ip_address):
    print "Regular UDP scan"


def display_banner_options():
    print "Welcome to Nmap Automator, please make a choice:"
    print "1] Live Host Scan"
    print "2] Simple TCP Scan"
    print "3] Full TCP Scan"
    print "4] Ultimate TCP Scan"
    print "5] Regular UDP Scan"
    print "------------------------------------------------------"


def main():
    display_banner_options()
    choice = raw_input("Choice>")
    print 'What is the IP address that you want to scan:'
    ip_address = raw_input("IP>")

    if choice == "1":
        live_host_scan(ip_address)
    elif choice == "2":
        simple_tcp_scan(ip_address)
    elif choice == "3":
        full_tcp_scan(ip_address)
    elif choice == "4":
        ultimate_tcp_scan(ip_address)
    elif choice == "5":
        regular_udp_scan(ip_address)
    else:
        print ('[!] Invalid Entry')
        exit(1)


if __name__ == '__main__':
    main()

