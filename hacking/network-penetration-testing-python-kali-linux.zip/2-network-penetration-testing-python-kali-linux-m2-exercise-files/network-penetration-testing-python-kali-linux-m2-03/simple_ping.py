def ping(ip):
    print 'Ping reply from ' + ip

def main():
    server_ip = '7.7.7.7'
    ping(server_ip)

if __name__ == "__main__":
    main()
