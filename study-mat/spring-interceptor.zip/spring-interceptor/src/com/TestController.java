package com;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/student")
public class TestController {
	

	
@RequestMapping(value="/admin/test1")
public String create(){
System.out.println("========================================/student/admin/test1");
	return "demo";
}

@RequestMapping(value="/tenant/test2/a")
public String createSubmit(){
	System.out.println("==========================================/student/tenant/test2");
	return "demo";
}
@RequestMapping(value="/bank/test1")
public String home(){
	System.out.println("==========================================/student/tenant/test2");
	return "demo";
}


}
